// welcome.js — step 3 of Safari setup: one button that asks Safari to allow
// the extension on the meeting sites.
//
// `permissions.request` must run inside the click (Safari rejects it otherwise),
// so the origins are read before the click and the request is the first await.
// Safari grants all of them or none. The result goes to the background script,
// which reports it to the Soda app.
//
// Three states: before, success (every site allowed), denied (Safari said no,
// or the prompt was closed). The page also turns to success if access is
// granted elsewhere, e.g. from the toolbar icon.

const api = globalThis.browser || globalThis.chrome;
const origins = sodaMeetingOrigins();

function show(state) {
  document.querySelectorAll('[data-state]').forEach((el) => {
    el.hidden = el.dataset.state !== state;
  });
}

async function allAllowed() {
  for (const origin of origins) {
    try {
      if (!(await api.permissions.contains({ origins: [origin] }))) return false;
    } catch (e) {
      return false; // SAFE: unknown counts as not allowed; the button stays.
    }
  }
  return origins.length > 0;
}

async function onAllowClick() {
  let granted = false;
  let errorClass = null;
  try {
    granted = await api.permissions.request({ origins });
  } catch (e) {
    errorClass = (e && e.name) || 'error';
  }
  show(granted && (await allAllowed()) ? 'success' : 'denied');
  try {
    await api.runtime.sendMessage({ type: 'soda_welcome_request_result', granted, error_class: errorClass });
  } catch (e) {
    // SAFE: the background also reports on permissions.onAdded.
  }
}

document.querySelectorAll('[data-allow]').forEach((button) => {
  button.addEventListener('click', onAllowClick);
});

api.permissions.onAdded.addListener(async () => {
  if (await allAllowed()) show('success');
});

allAllowed().then((ok) => show(ok ? 'success' : 'before'));

// A reused tab may be stale (opened earlier, then the sites were changed).
// Re-check whenever it comes back into view.
document.addEventListener('visibilitychange', async () => {
  if (document.visibilityState !== 'visible') return;
  const ok = await allAllowed();
  const current = document.querySelector('[data-state]:not([hidden])');
  if (ok) show('success');
  else if (current && current.dataset.state === 'success') show('before');
});

// The background script asks an open page to come forward rather than opening
// a second one (it cannot see our tabs' addresses without the "tabs"
// permission). Answering true tells it a page took care of it.
api.runtime.onMessage.addListener((message) => {
  if (!message || message.type !== 'soda_focus_welcome') return undefined;
  return (async () => {
    const tab = await api.tabs.getCurrent();
    if (!tab) return false;
    await api.tabs.update(tab.id, { active: true });
    if (tab.windowId != null) await api.windows.update(tab.windowId, { focused: true });
    return true;
  })().catch(() => false);
});
