// meeting-origins.js — the sites the extension asks Safari to allow.
//
// Loaded by the background script and by welcome.html. Read from the
// manifest's `content_scripts` matches so the list lives in one place: adding a
// meeting product is still one manifest entry.
//
// Safari ignores paths in host permissions, so each match is reduced to
// `https://<host>/*` ("https://*.zoom.us/wc/*" -> "https://*.zoom.us/*").

/* exported sodaMeetingOrigins */
function sodaMeetingOrigins() {
  const api = globalThis.browser || globalThis.chrome;
  const scripts = api.runtime.getManifest().content_scripts || [];
  const origins = new Set();
  for (const script of scripts) {
    for (const match of script.matches || []) {
      const m = /^(https?):\/\/([^/]+)\//.exec(match);
      if (m) origins.add(`${m[1]}://${m[2]}/*`);
    }
  }
  return Array.from(origins);
}
