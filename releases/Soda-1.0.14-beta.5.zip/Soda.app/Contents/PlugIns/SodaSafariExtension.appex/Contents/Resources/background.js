// background.js — Soda's Safari extension background script (non-persistent).
//
// It does two jobs:
//
//   1. SETUP. Turning the extension on in Safari Settings is not enough: Safari
//      also needs the user to allow the meeting sites, and it only shows a small
//      badge on the toolbar icon to say so. When the extension is first turned
//      on, this opens welcome.html, whose one button calls
//      `permissions.request` (Safari's own prompt). Safari requires that call to
//      come from a click, so it cannot be made from here.
//
//   2. REPORTING. It tells the Soda app which meeting sites are allowed, so the
//      app's setup screen can show "done" only when it really is. Reports go by
//      native message to the extension's helper (SafariWebExtensionHandler.swift),
//      which passes them to the app through a shared App Group. Reports carry
//      states, counts and the five public meeting host patterns only, never page
//      content or URLs.
//
// Safari gives the app no API to read per-site access, so this is the only way
// the app can know.

const api = globalThis.browser || globalThis.chrome;

// Safari ignores the application id; the message always goes to our own helper.
const NATIVE_APP_ID = 'app.getsoda.desktop';
const WELCOME_PATH = 'welcome.html';

async function accessState() {
  const requested = sodaMeetingOrigins();
  const granted = [];
  for (const origin of requested) {
    try {
      if (await api.permissions.contains({ origins: [origin] })) granted.push(origin);
    } catch (e) {
      // SAFE: a failed check counts as "not granted"; the report carries the count.
    }
  }
  return { requested, granted };
}

async function report(source, extra = {}) {
  const { requested, granted } = await accessState();
  const message = {
    type: 'access_state',
    source,
    report_id: crypto.randomUUID().toLowerCase(),
    sent_at_ms: Date.now(),
    ext_version: api.runtime.getManifest().version,
    welcome_url: api.runtime.getURL(WELCOME_PATH),
    requested_origins: requested,
    granted_origins: granted,
    ...extra,
  };
  try {
    await api.runtime.sendNativeMessage(NATIVE_APP_ID, message);
  } catch (e) {
    console.warn('[soda] native report failed', source, e && e.name);
  }
  return { requested, granted };
}

// Shows the welcome page in front: an open one if there is one, otherwise a
// new tab. Without the "tabs" permission Safari hides the address of our own
// tabs (tabs.query found none in the live test), so instead any open page is
// asked to bring itself forward (welcome.js answers). Focusing the window
// matters: Safari Settings is often in front. Returns 'focused' or 'created'.
async function openWelcome() {
  try {
    const answered = await api.runtime.sendMessage({ type: 'soda_focus_welcome' });
    if (answered === true) return 'focused';
  } catch (e) {
    // SAFE: no page open to answer; open one below.
  }
  const tab = await api.tabs.create({ url: api.runtime.getURL(WELCOME_PATH), active: true });
  if (tab && tab.windowId != null) {
    try {
      await api.windows.update(tab.windowId, { focused: true });
    } catch (e) {
      console.warn('[soda] window focus failed', e && e.name);
    }
  }
  return 'created';
}

// Turned on, or updated. The extension never opens the welcome page by
// itself: it is step 3 of Soda's setup and must only appear once steps 1 and
// 2 are done (Lloyd 2026-10-27), which only Soda knows. So report, and Soda,
// seeing the extension on, asks for the page if step 3 is active. That request
// has to reach this script while it is awake (Safari may already be in front,
// so no focus change wakes it), hence the two checks shortly after.
// WebKit fires `install` when the extension is switched on while Safari runs,
// and `update` when Safari loads a new version (a Soda update).
api.runtime.onInstalled.addListener(async (details) => {
  const reason = (details && details.reason) || 'unknown';
  await report(reason === 'install' ? 'installed' : 'updated', { install_reason: reason });
  setTimeout(checkPendingRequest, 1500);
  setTimeout(checkPendingRequest, 4000);
});

api.runtime.onStartup.addListener(() => { report('startup'); });

// Safari fires one event per site, so allowing all five fires five. Send one
// report for the burst.
let permissionsReportTimer = null;
function reportPermissionsChanged(source) {
  clearTimeout(permissionsReportTimer);
  permissionsReportTimer = setTimeout(() => report(source), 300);
}
api.permissions.onAdded.addListener(() => { reportPermissionsChanged('permissions_added'); });
api.permissions.onRemoved.addListener(() => { reportPermissionsChanged('permissions_removed'); });

// From the content script (it ran, so this site is allowed) and the welcome page.
api.runtime.onMessage.addListener((message) => {
  if (!message || typeof message !== 'object') return;
  if (message.type === 'soda_page_seen') {
    report('page_seen', {
      page_host: String(message.host || ''),
      is_top_frame: message.is_top_frame === true,
    });
  } else if (message.type === 'soda_welcome_request_result') {
    report('welcome_request', {
      request_granted: message.granted === true,
      error_class: message.error_class || null,
    });
  }
});

// Toolbar icon. On a meeting page whose site is not allowed, Safari shows its
// own prompt instead and this does not fire. Anywhere else it opens the
// welcome page, so "click the Soda icon" always leads to allowing the sites.
api.action.onClicked.addListener(async () => {
  let mode = null;
  try {
    mode = await openWelcome();
  } catch (e) {
    // SAFE: reported below as welcome_opened false.
  }
  report('toolbar_click', { welcome_opened: mode !== null, welcome_open_mode: mode });
});

// Soda asks for the welcome page by leaving a request with the helper and
// bringing Safari to the front. Safari waking this script is the only way the
// request reaches it: messages pushed from the app arrive only while it is
// awake, and Safari will not load an extension page opened from outside.
// So on a window focus change or tab switch, ask the helper whether a request
// is waiting (it hands each one out once, and only within 30 s).
let pendingCheckTimer = null;
async function checkPendingRequest() {
  let reply;
  try {
    reply = await api.runtime.sendNativeMessage(NATIVE_APP_ID, { type: 'pending_request' });
  } catch (e) {
    return;
  }
  if (!reply || reply.open_welcome !== true) return;
  let mode = null;
  try {
    mode = await openWelcome();
  } catch (e) {
    // SAFE: reported below as welcome_opened false.
  }
  report('app_request', { welcome_opened: mode !== null, welcome_open_mode: mode, via: 'pending_request' });
}
function scheduleCheck() {
  clearTimeout(pendingCheckTimer);
  pendingCheckTimer = setTimeout(checkPendingRequest, 200);
}
api.windows.onFocusChanged.addListener(scheduleCheck);
api.tabs.onActivated.addListener(scheduleCheck);

// From the Soda app (SFSafariApplication.dispatchMessage):
//   open_welcome  — step 3 of the setup screen wants the welcome page (only
//                   arrives while this script is awake)
//   report_access — the setup screen saw the extension switched on but no
//                   report yet; send one now
function connectAppPort() {
  let port;
  try {
    port = api.runtime.connectNative(NATIVE_APP_ID);
  } catch (e) {
    console.warn('[soda] connectNative failed', e && e.name);
    return;
  }
  port.onMessage.addListener(async (message) => {
    const name = message && (message.name || (message.message && message.message.name));
    if (name === 'report_access') {
      report('app_ping');
      return;
    }
    if (name !== 'open_welcome') return;
    let mode = null;
    try {
      mode = await openWelcome();
    } catch (e) {
      // SAFE: reported below as welcome_opened false.
    }
    report('app_request', { welcome_opened: mode !== null, welcome_open_mode: mode, via: 'dispatch' });
  });
}
connectAppPort();
