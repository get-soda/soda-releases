// aria-unhide.js — Soda's Safari content script.
//
// It does THREE things, and knows nothing about any meeting product:
//
//   1. remove `aria-hidden="true"` from every element
//   2. set `role="group"` on every <div> that has no role
//   3. add one empty marker <div id="soda-safari-extension"> as the first child
//      of <body> (see MARKER below)
//
// That is the entire extension. There are no selectors for speaking indicators,
// no participant logic, no messaging with the app. If Google redesigns Meet, this
// file does not change. All semantic work lives in the desktop app, which reads the
// resulting Accessibility tree.
//
// MARKER. The marker is product-agnostic (no page knowledge). It exists so the app
// can tell "the extension is running on this page" from "the page changed": the app
// finds it in the Accessibility tree. It is an empty, unnamed group, 1x1 px, clipped
// and not interactive. Most assistive technology ignores it; VoiceOver's cursor may
// land on it as "group". It never gets an aria-label, which would give it an
// accessible name VoiceOver reads out.
// The id and class names are a contract with the app
// (`SafariExtensionInfo.pageMarkerDomIdentifier` / `pageMarkerVersionClassPrefix`).
//
// ---------------------------------------------------------------------------
// WHY THIS IS NEEDED
//
// WebKit excludes elements from the Accessibility tree for TWO independent reasons:
//   (1) `aria-hidden="true"`  — excludes the element and its whole subtree
//   (2) semantic emptiness    — a generic element with no name/role is excluded
//                                even when it has no aria-hidden
//
// Meet marks the active speaker with a CSS class on an element that trips BOTH.
// Chromium keeps such nodes in the tree ("ignored but included") and still serves
// their class list, which is why the same detection works in Chrome unaided.
// WebKit drops them entirely, so Safari's tree is shallow and the signal invisible.
//
// Measured on a live 3-person call: this takes Safari's Meet tree from 100 nodes /
// depth 5 to 379 nodes / depth 21 — matching Chrome's depth 19 — and exposes the
// speaking class, which then attributes correctly to the speaking participant.
//
// ---------------------------------------------------------------------------
// TWO CHOICES THAT LOOK ARBITRARY AND ARE NOT
//
// * `role="group"` rather than `aria-label`. Both expose the node identically
//   (measured: same 379 nodes / depth 21). But aria-label OVERWRITES the element's
//   accessible name, which would wreck the page for VoiceOver users. role="group"
//   sets no name, so real accessible names are untouched.
//
// * NEVER `role="img"`. It makes descendants presentational, so the subtree
//   disappears — the opposite of what we want, and it fails silently.
//
// Scoped to meet.google.com, Zoom Web (*.zoom.us/wc/*) and Teams Web (teams.live.com,
// teams.microsoft.com, teams.cloud.microsoft) by the manifest. That
// is a URL match, not page knowledge: adding another meeting product is a manifest entry, not code.

(() => {
  'use strict';

  const ROLE = 'group';

  // Treat one element. Cheap and idempotent — safe to call repeatedly.
  const treat = (el) => {
    if (el.hasAttribute('aria-hidden')) el.removeAttribute('aria-hidden');
    if (el.tagName === 'DIV' && !el.hasAttribute('role')) el.setAttribute('role', ROLE);
  };

  const treatTree = (root) => {
    if (root.nodeType !== Node.ELEMENT_NODE) return;
    treat(root);
    const els = root.getElementsByTagName('*');
    for (let i = 0; i < els.length; i++) treat(els[i]);
  };

  // MARKER: created once per frame this script runs in.
  const marker = document.createElement('div');
  marker.id = 'soda-safari-extension';
  marker.classList.add('soda-safari-extension', 'soda-safari-extension--v1');
  try {
    const version = (globalThis.browser || globalThis.chrome)?.runtime?.getManifest?.().version;
    if (version) marker.classList.add('soda-safari-extension--ext-' + String(version).replace(/\./g, '-'));
  } catch (e) {
    // No version class; the app treats the version as unknown.
  }
  marker.setAttribute('role', ROLE);
  marker.setAttribute('style',
    'position:fixed;left:0;top:0;width:1px;height:1px;overflow:hidden;' +
    'clip-path:inset(50%);pointer-events:none;');

  // Meet re-renders constantly. Process only what actually changed rather than
  // re-scanning the document — a full re-scan per mutation is what made the
  // research prototype visibly slow on a busy call.
  const observer = new MutationObserver((records) => {
    // Page scripts can wipe <body>'s children: put the marker back. The prepend
    // queues its own childList record, which re-enters this callback, finds the
    // marker connected, and stops. No loop.
    if (!marker.isConnected && document.body) document.body.prepend(marker);
    for (const r of records) {
      if (r.type === 'attributes') {
        if (r.target.nodeType === Node.ELEMENT_NODE) treat(r.target);
      } else {
        for (const node of r.addedNodes) treatTree(node);
      }
    }
  });

  const start = () => {
    if (!document.body) return;
    // prepend, not append: the app's AX walk has a node cap, so the marker must
    // sit early in a depth-first walk.
    document.body.prepend(marker);
    treatTree(document.body);
    // attributeFilter is deliberately narrow: we observe aria-hidden and only ever
    // REMOVE it, so the re-triggered callback finds nothing to change and settles.
    // `role` writes are not observed, so they cannot feed back either. A broader
    // filter here would loop.
    observer.observe(document.body, {
      subtree: true,
      childList: true,
      attributes: true,
      attributeFilter: ['aria-hidden']
    });
  };

  if (document.body) {
    start();
  } else {
    // run_at document_start means <body> may not exist yet.
    document.addEventListener('DOMContentLoaded', start, { once: true });
  }
})();
